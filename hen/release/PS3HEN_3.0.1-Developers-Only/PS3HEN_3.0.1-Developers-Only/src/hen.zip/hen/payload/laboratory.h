#ifndef __LABORATORY_H__
#define __LABORATORY_H__

void do_dump_threads_info_test(void);
void do_dump_processes_test(void);
void do_hook_load_module(void);
void do_hook_mutex_create(void);
void do_ps2net_copy_test(void);
void do_dump_modules_info_test(void);
void do_pad_test(void);

#endif

 
