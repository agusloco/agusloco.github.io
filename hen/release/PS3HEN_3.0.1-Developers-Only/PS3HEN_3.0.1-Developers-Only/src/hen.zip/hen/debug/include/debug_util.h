#ifdef LV2

#ifndef __DEBUG_UTIL_H__
#define __DEBUG_UTIL_H__

#include <lv2/process.h>

void debug_print_modules(process_t process);

#endif

#endif

